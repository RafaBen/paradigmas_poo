package app;

import ui.Ui;

public class App {
    public static void main(String[] args) throws Exception {
        Ui questoes = new Ui();

        //questoes.questao1();

        //questoes.questao2();

        //questoes.questao3();

        //questoes.questao4();

        //questoes.questao5();

        // questoes.questao6();

        //questoes.questao7();

        //questoes.questao8();

        //questoes.questao9();

        //questoes.questao10();

        //questoes.questao11();

        //questoes.questao12();

        //questoes.questao13();

        //questoes.questao14();

        //questoes.questao15();
        
    }


   
}
