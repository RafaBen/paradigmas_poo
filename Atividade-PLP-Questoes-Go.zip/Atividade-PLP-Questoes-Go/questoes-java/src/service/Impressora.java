package service;

public interface Impressora {
    void imprimir();
}
