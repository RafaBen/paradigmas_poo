package util;

import service.Impressora;

public class Relatorio implements Impressora {
    public void imprimir(){
        System.out.println("Imprimindo relatorio");
    }
   
}
