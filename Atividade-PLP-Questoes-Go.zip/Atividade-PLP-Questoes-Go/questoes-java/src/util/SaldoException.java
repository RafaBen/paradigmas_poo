package util;

public class SaldoException extends Exception {

    public SaldoException(String mensagem) {
        super(mensagem);
    }
}
