package util;

import service.Som;

public class Animal extends Som {
    public void somGato(){
        System.out.println("O gato faz: Miau!");
    }

    public void somCachorro(){
        System.out.println("O cachorro faz: Au Au!");
    }
}
